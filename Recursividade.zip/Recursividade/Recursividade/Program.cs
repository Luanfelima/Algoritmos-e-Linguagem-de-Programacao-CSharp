﻿using System;

namespace Recursividade
{
    class Program
    {
        static void Main(string[] args)
        {
            double n;

            Console.WriteLine("Insira o numero fatorial");

            n = double.Parse(Console.ReadLine());

            Console.WriteLine("Fatorial de {0} = {1}", n, fatorial(n));
                       
            Console.ReadKey();
        }

        static double fatorial(double n)
        {

            if (n == 0)
                return 1;

            else

                return (n * fatorial(n - 1));

        }
    }
}
