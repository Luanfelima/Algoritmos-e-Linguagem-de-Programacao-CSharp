﻿using System;

namespace Tarefa_20___100_a_1_com_For
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;

            Console.WriteLine("Olá, esse programa ira utilizar o comando for, para efetuar um loop de 100 à 1");

            for (i = 100; i >= 1; i--)
            {
               Console.WriteLine("Os valores são: {0}", i);
            }

            Console.ReadKey();
        }
    }
}
