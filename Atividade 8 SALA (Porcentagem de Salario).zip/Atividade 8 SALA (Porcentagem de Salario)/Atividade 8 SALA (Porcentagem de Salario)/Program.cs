﻿using System;

namespace Atividade_8_SALA
{
    class Program
    {
        static void Main(string[] args)
        {
            double salarioatual, aumento, salariofuturo, porcentagem;

            Console.WriteLine("Olá, o Senhor(a) poderia informar o valor do seu Salário atual: ");
            salarioatual = double.Parse(Console.ReadLine());

            Console.WriteLine("E qual seria a porcentagem de aumento de seu Salário: ");
            porcentagem = double.Parse(Console.ReadLine());
            
            Console.WriteLine("Computando...");

            aumento = (porcentagem / 100.0) * salarioatual; //Calcula o valor do aumento, já agregado com porcentagem
            salariofuturo = salarioatual + aumento; //Soma aumento com salario atual e armazena no salario futuro

            /*
            Também pode ser feito desta maneira:
            
            porcentagem = aumento * 0.01 * salarioatual; //Calcula apenas o valor da porcentagem de aumento
            salariofuturo = aumento * 0.01 * salarioatual + salarioatual; //Calcula o valor do salario futuro, já com aumento agregado.
            */

            Console.WriteLine("O salário anterior do Senhor(a) era de {0}, o valor da porcentagem de aumento foi de: {1}%, essa porcentagem para reais é de: {2}, e seu futuro salário será de: {3}", salarioatual, porcentagem, aumento, salariofuturo);
            Console.ReadKey();

        }
    }
}