﻿using System;

namespace Exercicio_4_de_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] notas = new double[20];
            double soma = 0, media, maior_nota = 0;
            int i, quantidade_de_alunos = 0;

            Console.WriteLine("Neste programa vamos ler a nota da prova de 20 alunos armazenando em um vetor. Calcular e imprimir a média geral dos alunos. E imprimir a maior nota da turma.");
            Console.WriteLine("");

            Console.WriteLine("Insira aqui as notas dos 20 alunos");
            Console.WriteLine("");

            for (i = 0; i <= 19; i++)
            {
                notas[i] = double.Parse(Console.ReadLine());

                if (notas[i] > 10)
                {
                    Console.WriteLine("Nota Invalida!! \nInsira novamente.");
                    Console.WriteLine("");
                    return;
                }

                soma = soma + notas[i];
                quantidade_de_alunos = quantidade_de_alunos + 1;

            }

            media = soma / quantidade_de_alunos;

            for(i = 0; i <= 19; i++)
            {
                if (notas[i] > maior_nota)
                {
                    maior_nota = notas[i];
                }
            }

            Console.WriteLine("A média geral dos alunos é de: {0}. \nE a maior nota da turma é: {1}", media, maior_nota);

            Console.ReadKey();
        }
    }
}
