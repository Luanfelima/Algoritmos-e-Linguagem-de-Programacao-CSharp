﻿using System;

namespace Exercicio_9___Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] v = new int[10];
            int i, valoresimpares = 0;
            double media = 0, soma = 0;

            Console.WriteLine("Neste programa vamos armezanar 10 valores inteiros e maiores que 0, e exibir a média aritmética de todos os números ímpares.");
            Console.WriteLine("");
            
            for(i = 0; i <= 9; i++)
            {
                Console.Write("Insira aqui os valores: ");
                Console.WriteLine("");
                v[i] = int.Parse(Console.ReadLine());

                if (v[i] < 0)
                {
                    Console.WriteLine("Valor inserido invalido, Favor, Repetir a operação!!");
                    return;

                }

            }
            
            for (i = 0; i <= 9; i++)
            {

                if (v[i] % 2 != 0)
                {
                    soma = soma + v[i];
                    valoresimpares = valoresimpares + 1;
                }

                media = soma / valoresimpares;

            }

            Console.WriteLine("A Média dos números ímpares inseridos são de: {0}.", media);

            Console.ReadKey();
        }
    }
}
