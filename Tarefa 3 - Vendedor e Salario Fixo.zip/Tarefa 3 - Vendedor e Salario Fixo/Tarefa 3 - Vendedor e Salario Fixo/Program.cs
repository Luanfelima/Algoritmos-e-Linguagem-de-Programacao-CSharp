﻿using System;

namespace Tarefa_3___Vendedor_e_Salario_Fixo
{
    class Program
    {
        static void Main(string[] args)
        {
            String Nome;
            Double salarioFixo, totalVendas, salarioFinal, comissao;

            Console.WriteLine("Olá cliente, tudo bem? Este programa irá calcular suas vendas e apresentar seu salário no final do mês");
            Console.WriteLine("");

            Console.WriteLine("Portanto, insira seu nome completo.");
            Nome = Console.ReadLine();
            Console.WriteLine("");

            Console.WriteLine("Olá senhor(a) {0}, a partir de agora o programa vai se iniciar, tenha um bom uso!!", Nome);
            Console.WriteLine("");

            Console.WriteLine("Insira seu sálario fixo");
            salarioFixo = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("Agora, insira o total de vendas em dinheiro no mês");
            totalVendas = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("Calculando...");
            Console.WriteLine("Calculando...");
            Console.WriteLine("");

            Console.WriteLine("Calculo efetuado. \nPressione Enter para concluir a operação.");
            Console.ReadKey();
            Console.WriteLine("");//pular linha
            Console.WriteLine(""); 


            comissao = (totalVendas * 0.20) + totalVendas;
            //Primeira operação realizada é 20% do total de vendas. Depois ele soma os 20% no seu total de vendas.
            salarioFinal = comissao + salarioFixo;
            //Aqui ela soma seu total de vendas + salário fixo.
           
            Console.WriteLine("Senhor(a) {0} contabilizamos seus calculos. \nSeu salário fixo é de: {1}, seu total de vendas em reais foi de: {2}, e por fim, seu salário final será de: {3} reais.", Nome, salarioFixo, comissao, salarioFinal);

            Console.ReadKey();

        }
    }
}
