﻿using System;

namespace Atividade_SALA__do_20_ao_1_com_While
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 20;

            Console.WriteLine("Aqui neste programa iremos fazer a ordem decrescente, portanto do 20 ao 1");
            Console.WriteLine("");

            while(i >= 1)
            {
                Console.WriteLine("O número é: {0}", i);
                i--;
            }





        }
    }
}
