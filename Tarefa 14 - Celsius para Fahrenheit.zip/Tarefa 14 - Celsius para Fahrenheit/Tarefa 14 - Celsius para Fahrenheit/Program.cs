﻿using System;

namespace Tarefa_14___Celsius_para_Fahrenheit
{
    class Program
    {
        static void Main(string[] args)
        {
            int c, f;

            Console.WriteLine("Olá, esse programa efetua a coversão de Celsius para Fahrenheit.");
            Console.WriteLine("");

            Console.Write("Insira aqui o valor em Graus Celsius: ");
            c = int.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("Temperatura salva!! \nAguarde um instante... \nEfetuando calculo...");
            Console.ReadKey();
            Console.WriteLine("");
            
            f = (9 * c + 160) / 5;

            Console.WriteLine("Resultado efetuado!! \nPressione Enter para mostra-lô na tela.");
            Console.ReadKey();
            Console.WriteLine("");

            Console.WriteLine("A temperatura em Graus Celsius é de: {0}, e em Fahrenheit é de: {1}", c, f);

            Console.ReadKey();

        }
    }
}
