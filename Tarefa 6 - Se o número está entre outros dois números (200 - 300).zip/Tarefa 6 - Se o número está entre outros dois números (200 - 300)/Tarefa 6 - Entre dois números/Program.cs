﻿using System;

namespace Tarefa_6___Entre_dois_números
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1;

            Console.WriteLine("Olá, seja bem vindo, ao programa, comparador numérico.");
            Console.WriteLine("");

            Console.WriteLine("Digite aqui o número que será comparado: ");
            num1 = double.Parse(Console.ReadLine());
            Console.WriteLine("");


            if (num1 >= 200 && num1 <= 300)
            {
                Console.WriteLine("Seu número está entre os pré selecionados!!!");
            }

            else
            {
                Console.WriteLine("Seu número está fora dos padrões");
            }

            Console.ReadKey();

        }
    }
}
