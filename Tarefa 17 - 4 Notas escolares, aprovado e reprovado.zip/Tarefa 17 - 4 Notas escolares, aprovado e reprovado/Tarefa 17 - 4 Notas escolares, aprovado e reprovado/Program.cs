﻿using System;

namespace Tarefa_17___4_Notas_escolares__aprovado_e_reprovado
{
    class Program
    {
        static void Main(string[] args)
        {
            string aluno;
            double n1, n2, n3, n4, media;

            Console.WriteLine("Olá professor, aqui vamos calcular a média de seus aluninhos(as) queridos.");
            Console.WriteLine("");

            Console.WriteLine("Inicialmente qual o nome deste(a) aluno(a)?");
            aluno = Console.ReadLine();
            Console.WriteLine("");

            Console.WriteLine("Ok, informação armazenada com sucesso!!!\nPressione Enter para continuar.");
            Console.ReadKey();
            Console.WriteLine("");

            Console.WriteLine("Insira aqui, a primeira nota do aluno(a): {0}", aluno);
            n1 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.WriteLine("Agora, insira a segunda nota do aluno(a): {0}", aluno);
            n2 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.WriteLine("Aqui, insira a terceira nota do aluno(a): {0}", aluno);
            n3 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.WriteLine("E por último, insira a quarta nota do aluno(a): {0}", aluno);
            n4 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            media = (n1 + n2 + n3 + n4) / 4;
            Math.Round(media); //arredondando

            Console.WriteLine("Contabilizando...");
            Console.WriteLine("");

            Console.WriteLine("Pressione Enter para continuar.");
            Console.ReadKey();
            Console.WriteLine("");

            Console.WriteLine("A média aritimetica do aluno(a): {0} \nFoi de: {1}", aluno, media);
            Console.WriteLine("");

            if (media >= 6)
            {
                Console.WriteLine("Ele está aprovado!!");
            }

            if (media == 5)
            {
                Console.WriteLine("Deverá ser levado ao Conselho de Classe");
            }

            if (media < 5)
            {
                Console.WriteLine("Reprovado!!");
            }

            Console.ReadKey();

        }
    }
}
