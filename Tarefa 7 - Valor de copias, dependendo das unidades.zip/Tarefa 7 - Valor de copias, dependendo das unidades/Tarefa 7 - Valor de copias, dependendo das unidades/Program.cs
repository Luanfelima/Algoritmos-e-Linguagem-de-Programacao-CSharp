﻿using System;

namespace Tarefa_7___Valor_de_copias__dependendo_das_unidades
{
    class Program
    {
        static void Main(string[] args)
        {
            double xerox1, xerox2, folhas;

            Console.WriteLine("Olá, faremos os calculos da quantidade de folhas, para sabermos o preço do xerox");
            Console.WriteLine("");

            Console.WriteLine("Digite a quantidade de folhas para xerox: ");
            folhas = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            

             if(folhas <= 200)
             {
                xerox1 = folhas * 0.50;

                Console.WriteLine("O valor do xerox é de: {0}, pois a quantidade foi de: {1}", xerox1, folhas);
                Math.Round(xerox1); //arredondando
             }
            
            if (folhas >= 201)
            {
                xerox2 = folhas * 0.30;
                Console.WriteLine("O valor do xerox é de: {0} reais, pois a quantidade foi de: {1} folhas", xerox2, folhas);
                Math.Round(xerox2); //arredondando
            }
              Console.ReadKey();
        }
    }
}
