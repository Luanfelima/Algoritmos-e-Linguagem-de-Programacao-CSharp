﻿using System;

namespace Exercicio_1_de_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] v = new double[15];
            double[] vcubo = new double[15];
            int i;

       
            Console.WriteLine("Neste programa vamos ler 15 valores e armazená-los em um array, e calcular o cubo armazenando em outro array");
            Console.WriteLine("");

            Console.WriteLine("Insira aqui os valores: ");
            Console.WriteLine("");

            for(i = 0; i <= 14; i++)
            {
                v[i] = double.Parse(Console.ReadLine());
            }
            
            for(i = 0; i <= 14; i++)
            {
                vcubo[i] = v[i] * v[i] * v[i];
                Console.WriteLine("O Cubo do número {0}, é de: {1}.", v[i], vcubo[i]);
            }

            Console.ReadKey();
        }
    }
}
