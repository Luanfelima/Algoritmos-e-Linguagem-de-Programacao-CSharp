﻿using System;

namespace Tarefa_16___Números_inteiros_em_ordem_crescente
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3, aux;

            Console.WriteLine("Olá, neste programa iremos colocar 3 números inteiros em ordem crescentes.");
            Console.WriteLine("");

            Console.Write("Insira aqui o primeiro número: ");
            num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.Write("Agora, insira o segundo número: ");
            num2 = int.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.Write("E por último o terceiro número: ");
            num3 = int.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("Calculando... \nCalculo efetuado, pressione Enter para continuar!");
            Console.ReadKey();
            Console.WriteLine("");

            if (num1 > num2)
            {
                aux = num1;
                num1 = num2;
                num2 = aux;
            }

            if (num1 > num3)
            {
                aux = num1;
                num1 = num3;
                num3 = aux;
            }

            if (num2 > num3)
            {
                aux = num1;
                num1 = num3;
                num3 = aux;
            }

            Console.WriteLine("Os números ordenados ficaram: Primeiro Número: {0}, Segundo Número: {1} e Terceiro Número: {2}", num1, num2, num3);

            Console.ReadKey();
        }
    }
}
