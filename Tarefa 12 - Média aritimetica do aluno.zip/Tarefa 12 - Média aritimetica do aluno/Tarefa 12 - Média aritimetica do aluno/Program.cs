﻿using System;

namespace Tarefa_12___Média_aritimetica_do_aluno
{
    class Program
    {
        static void Main(string[] args)
        {
            string aluno;
            double n1, n2, n3, media;

            Console.WriteLine("Olá professor, vamos calcular a média de seus queridos alunos(as).");
            Console.WriteLine("");

            Console.WriteLine("Inicialmente qual o nome deste(a) aluno(a)?");
            aluno = Console.ReadLine();
            Console.WriteLine("");

            Console.WriteLine("Ok, informação armazenada com sucesso!!!\nPressione Enter para continuar.");
            Console.ReadKey();
            Console.WriteLine("");

            Console.WriteLine("Insira aqui, a primeira nota do aluno(a): {0}", aluno);
            n1 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.WriteLine("Agora, insira a segunda nota do aluno(a): {0}", aluno);
            n2 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.WriteLine("E por fim, insira a terceira nota do aluno(a): {0}", aluno);
            n3 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            media = (n1 + n2 + n3) / 3;
            Math.Round(media); //arredondando

            Console.WriteLine("Contabilizando...");
            Console.WriteLine("");

            Console.WriteLine("Pressione Enter para continuar.");
            Console.ReadKey();
            Console.WriteLine("");

            Console.WriteLine("A média aritimetica do aluno(a): {0} \nFoi de: {1}", aluno, media);
            Console.WriteLine("");

            if (media >=7)
            {
                Console.WriteLine("Ele está aprovado!!");
            }

            if(media == 6)
            {
                Console.WriteLine("Deverá ser levado ao Conselho de Classe");
            }

            if(media < 6)
            {
                Console.WriteLine("Reprovado!!");
            }

            Console.ReadKey();

        }
    }
}
