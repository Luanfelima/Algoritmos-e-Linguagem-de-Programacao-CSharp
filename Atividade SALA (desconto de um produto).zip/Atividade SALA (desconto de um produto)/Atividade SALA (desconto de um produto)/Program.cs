﻿using System;

namespace Atividade_SALA__desconto_de_um_produto_
{
    class Program
    {
        static void Main(string[] args)
        {
            double preço, preçoTotal, desconto;
            int quantidade;


            Console.WriteLine("Neste programa vamos efetuar um desconto, caso o cliente compre uma quantidade superior de 10 unidades");

            Console.WriteLine("");

            Console.Write("Informe o preço do seu produto: ");
            preço = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.Write("Agora insira a quantidade de produtos comprada pelo cliente: ");
            quantidade = int.Parse(Console.ReadLine());

            Console.WriteLine("");



            if (quantidade >= 10)
            {
                desconto = (preço * 0.10);
                preçoTotal = (preço - desconto);

                Console.WriteLine("O preço foi de: {0} Reais, a quantidade comprada foi de: {1} unidades e o valor final, aplicando 10% de desconto, foi de: {2} Reais", preço, quantidade, preçoTotal);
            }
            else
            {
                Console.WriteLine("O preço foi de: {0} Reais, a quantidade comprada foi de: {1} unidades", preço, quantidade);
            }
            
           Console.ReadKey();
        }
    }
}
