﻿using System;

namespace Exercicio_3_de_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] v = new int[99];
            int i;

            
            Console.WriteLine("Neste programa vamos ler 99 valores inteiros e mostrar na tela os valores lidos na ordem inversa");
            Console.WriteLine("");

            for(i = 0; i <= 98; i++)
            {
                Console.Write("Insira aqui o valor: ");
                Console.WriteLine("");

                v[i] = int.Parse(Console.ReadLine());

            }

            Console.WriteLine("");
            Console.WriteLine("Agora lendo inversamente os valores inseridos...");
            Console.WriteLine("");
            Console.WriteLine("Aperte uma tecla para continuar!");
            Console.ReadKey();
            Console.WriteLine("");

            for (i = 98; i >= 0; i--)
            {
                Console.WriteLine("O valor inserido na posição {0} é o {1}", i, v[i]);
            }
         
            Console.ReadKey();
        }
    }
}
