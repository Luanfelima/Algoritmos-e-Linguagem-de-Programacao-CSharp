﻿using System;

namespace Serie_de_Fibonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;

            Console.WriteLine("Insira aqui o número, para calcular na sequencia de fibonacci");
            n = int.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("Fibonacci de {0} = {1}", n, fibonacci(n));
            Console.ReadKey();

        }
        
        static int fibonacci (int n)
        {
            if (n == 0)

                return 0;

            if (n == 1)

                return 1;

            return fibonacci(n - 1) + fibonacci(n - 2);

        }
    }
}
