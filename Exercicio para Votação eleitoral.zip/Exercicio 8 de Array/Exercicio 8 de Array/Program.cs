﻿using System;

namespace Exercicio_8_de_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] votos = new double[10]; //exemplo com 10 votos
            int i, branco = 0, nulo = 0, candidato_1 = 0, candidato_2 = 0, votos_computados = 0;
            
            for(i = 0; i <= 9; i++)
            {
                Console.WriteLine("Caro eleitor, registre aqui seu voto, e essas são as legendas disponíveis:\n 1 - Candidato 1.\n 2 - Candidato 2.\n 3 - Nulo.\n 4 - Branco.");
                Console.WriteLine("");
                votos[i] = double.Parse(Console.ReadLine());

                if(votos[i] == 1)
                {
                    candidato_1++;
                    Console.WriteLine("");
                    Console.WriteLine("Voto computado com sucesso, o seu país agradece a colaboração!!");
                    Console.WriteLine("");
                }

                if(votos[i] == 2)
                {
                    candidato_2++;
                    Console.WriteLine("");
                    Console.WriteLine("Voto computado com sucesso, o seu país agradece a colaboração!!");
                    Console.WriteLine("");
                }

                if(votos[i] == 3)
                {
                    nulo++;
                    Console.WriteLine("");
                    Console.WriteLine("Voto computado com sucesso, o seu país agradece a colaboração!!");
                    Console.WriteLine("");
                }

                if(votos[i] == 4)
                {
                    branco++;
                    Console.WriteLine("");
                    Console.WriteLine("Voto computado com sucesso, o seu país agradece a colaboração!!");
                    Console.WriteLine("");

                    if(candidato_1 > candidato_2)
                    {
                        candidato_1++;
                    }

                    if (candidato_2 > candidato_1)
                    {
                        candidato_2++;
                    }
                }

                if(votos[i] > 4)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Esta legenda não existe, refaça o processo, e coopere com seu país.");
                    return;
                }

                votos_computados++;

            }

            if(candidato_1 > candidato_2)
            {
                Console.WriteLine("Senhora e Senhores. O(a) candidato 1 ganhou a Eleição Presidencial de 2022!!\nCom {0} votos", candidato_1);
                Console.WriteLine("");
            }

            if(candidato_2 > candidato_1)
            {
                Console.WriteLine("Senhora e Senhores. O(a) candidato 2 ganhou a Eleição Presidencial de 2022!!\nCom {0} votos", candidato_2);
                Console.WriteLine("");
            }

            if(candidato_1 == candidato_2)
            {
                Console.WriteLine("Senhora e Senhores. A votação está empatada, terá uma segunda fase na próxima semana, com os mesmos candidatos. Obrigado pela cooperação!!");
                Console.WriteLine("");
            }

            Console.WriteLine("A quantidade de votos em nulo foi de: {0}.\nA quantidade de votos em Branco foi de: {1}.\nE o total de votos computados foram de: {2}", nulo, branco, votos_computados);
            Console.ReadKey();
        }
    }
}
