﻿using System;

namespace Atividade_SALA_Peso_de_prova
{
    class Program
    {
        static void Main(string[] args)
        {
            double n1, n2, n3, n1p, n2p, n3p, media;
            string nome;

            Console.WriteLine("Neste programa vamos calcular a média dos alunos!!");

            Console.WriteLine("");

            Console.Write("Insira o nome do Aluno(a): ");
            nome = Console.ReadLine();

            Console.WriteLine("");

            Console.Write("Insira a primeira nota do(a) aluno(a) {0}: ", nome);
            n1 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.Write("Agora insira a segunda nota: ");
            n2 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.Write("E por último insira a terceira nota: ");
            n3 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            Console.WriteLine("Calculando...");

            Console.WriteLine("");

            Console.WriteLine("Pressione enter para continuar!!");
            Console.ReadKey();

            Console.WriteLine("");

            n1p = n1 * 2;      
            n2p = n2 * 3;      
            n3p = n3 * 4;

            media = (n1p + n2p + n3p) / 9;
            

            if (media >= 6)
            {
                Console.WriteLine("O(a) Aluno(a) {0}, Aprovado(a)!!!", nome);
            }

            if (media < 6 && media > 4)
            {
                Console.WriteLine("O(a) Aluno(a) {0}, Deverá ser enviado(a) para o Conselho!!!", nome);
            }

            if (media < 5)
            {
                Console.WriteLine("O(a) Aluno(a) {0}, Reprovado(a)!!!", nome);
            }

            Console.ReadKey();
        }
    }
}
