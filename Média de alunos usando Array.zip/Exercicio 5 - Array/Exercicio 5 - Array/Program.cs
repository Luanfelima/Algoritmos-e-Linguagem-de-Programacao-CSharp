﻿using System;

namespace Exercicio_5___Array
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] notas = new double[16];
            double media, somadasnotas = 0;
            int i, abaixomedia = 0;


            Console.WriteLine("Neste programa vamos ler as notas de 15 alunos armazená-las em um vetor, calcular e mostrar a media geral, e apos calculo, mostrar quantidade de alunos abaixo da média");
            Console.WriteLine("");

            for (i = 0; i <= 15; i++)
            {
                Console.WriteLine("Insira aqui a nota do aluno {0}: ", i);
                notas[i] = double.Parse(Console.ReadLine());
                Console.WriteLine("");

                if (notas[i] > 10)
                {
                    Console.WriteLine("Valor invalido, favor inserir novamente!!");
                    Console.ReadKey();
                    return;
                }

                somadasnotas = somadasnotas + notas[i];

            }

            media = somadasnotas / 15;


            for (i = 0; i <= 15; i++)
            {
                if (notas[i] < media)
                {
                    abaixomedia = abaixomedia + 1;
                }
            }

            Console.WriteLine("A média dos 15 alunos foi de: {0}. \nE a quantidade de alunos abaixo da média foi de: {1}.", media, abaixomedia);
            Console.ReadKey();
        }
    }
}
