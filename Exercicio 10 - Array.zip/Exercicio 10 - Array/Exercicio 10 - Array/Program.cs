﻿using System;

namespace Exercicio_10___Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] v = new int[10];
            int i;



            Console.WriteLine("Neste programa iremos ler 10 valores maiores que 0 e inteiros, armazenar, os elementos negativos serão == 99, e pares == 33, e imprimiremos todos os dados");
            Console.WriteLine("");

            for(i = 0; i <=9; i++)
            {
                Console.Write("Insira aqui, valores maiores que 0 e inteiros: ");
                Console.WriteLine("");
                v[i] = int.Parse(Console.ReadLine());                
            }


            for (i = 0; i <= 9; i++)
            {
               if (v[i] < 0)
               {
                   v[i] = 99; 
               }

               if (v[i] % 2 == 0)
               {
                   v[i] = 33;              
               }

                Console.WriteLine("Os valores são: {0}", v[i]);

            }
      
            Console.ReadKey();
        }
    }
}
