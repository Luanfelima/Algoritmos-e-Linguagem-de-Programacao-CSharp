﻿using System;

namespace Tarefa_4___Média_ponderada_n1__n2__n3
{
    class Program
    {
        static void Main(string[] args)
        {
            String aluno;
            Double n1, n2, n3, n1p, n2p, n3p, media;
            
            //n1p, n2p e n3p são as notas com seus devidos pesos.
                                    
            Console.WriteLine("Olá professor(a), aqui veremos se seu aluno realmente merece passar para o proximo semestre");

            Console.WriteLine("Insira aqui o nome do aluno: ");
            aluno = Console.ReadLine();
            Console.WriteLine("");

            Console.WriteLine("Agora, me diga qual foi a n1 deste aluno: ");
            n1 = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("E qual foi a n2 deste aluno: ");
            n2 = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("E por último, qual foi a n3 deste aluno: ");
            n3 = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            n1p = 2 * n1;
            n2p = 4 * n2;
            n3p = 6 * n3;

            media = (n1p + n2p + n3p) / 12;
            media = Math.Round(media); //arredondamento de números decimais.

            Console.WriteLine("O(a) aluno(a) {0} teve a média ponderada de {1}", aluno, media);
            Console.WriteLine("Portanto o resultado foi de: ");
            Console.WriteLine("");
            Console.ReadKey();
            
            if (media >= 6)
            {
                Console.WriteLine("Parabéns Aprovado!!\nNos encontramos no próximo semestre.");
            }

            else
            {
                Console.WriteLine("Reprovado. Irá cursar o semestre novamente!!\nNos encontramos no mesmo semestre!");
            }

        }
    }
}
