﻿using System;

namespace Exercicio_7_de_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] valorPago = new double[300];
            double receita = 0;
            int formaPagamento;
            int i, cartão = 0, cheque = 0, cédula = 0;
               
              for (i = 0; i <= 299; i++)
              {
                    Console.WriteLine("Insira a forma de pagamento do cliente {0}, conforme o código:\n1 - Cédula;\n2 - Cartão;\n3 - Cheque.\n", i);

                    formaPagamento = int.Parse(Console.ReadLine());

                   if (formaPagamento == 1)
                   {
                        cédula++;
                   }

                   if (formaPagamento == 2)
                   {
                        cartão++;
                   }

                   if (formaPagamento == 3)
                   {
                        cheque++;
                   }

                   if (formaPagamento > 4)
                   {
                        Console.WriteLine("Forma de pagamamento invalida. Inserir os valores novamente!!");
                        return;
                   }

                  Console.WriteLine("");
                  Console.WriteLine("Insira o valor pago (em R$) do cliente {0}:", i);
                  valorPago[i] = double.Parse(Console.ReadLine());
                  receita = receita + valorPago[i];

                  Console.WriteLine("");
              }

            Console.WriteLine("");
            Console.WriteLine("Pagamento em cartão: " + cartão);
            Console.WriteLine("");
            Console.WriteLine("Pagamento em cheque: " + cheque);
            Console.WriteLine("");
            Console.WriteLine("Pagamento em cédula: " + cédula);
            Console.WriteLine("");
            Console.WriteLine("Receita: R$ " + receita);
            
            Console.ReadKey();
        }
    }
}
