﻿using System;

namespace Exercicio_8___Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] v = new int[10];
            int i, soma = 0;


            Console.WriteLine("Neste programa, vamos ler 10 números inteiros e maiores de zero, armazená-los no array, e exibir a soma dos pares.");
            Console.WriteLine("");

            for(i = 0; i <= 9; i++)
            {
                Console.Write("Insira números inteiros e maiores que zero, aqui:");
                Console.WriteLine("");
                v[i] = int.Parse(Console.ReadLine());

                if (v[i] < 0)
                {
                    Console.WriteLine("Valor negativo!! \nRetorne ao programa!");
                    Console.WriteLine("");
                    return;
                }
            }


            for(i = 0; i <= 9; i++)
            {
                if(v[i] % 2 == 0)
                {
                   soma = soma + v[i];
                }   
            }

            Console.WriteLine("A soma dos números pares é igual a: {0}.", soma);

            Console.ReadKey();
        }
    }
}
